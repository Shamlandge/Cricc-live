CRICC LIVE - starter website
1. Extract cricc-live.zip.
2. Open index.html to preview locally in a browser.
3. To publish free: create a GitHub account, create a PUBLIC repository named cricc-live, upload index.html, then open Settings > Pages.
4. Under Build and deployment choose Deploy from a branch, select main and /(root), then Save.
5. Wait for GitHub Pages to publish. Your address will be https://YOUR-USERNAME.github.io/cricc-live/

IMPORTANT:
- Match scores on this starter site are sample/demo data only.
- A verified cricket data API and its terms/permissions are required for real-time scores.
- Do not put private API keys in browser JavaScript. Use a secure server-side function if the API requires a secret.
